# most to do items were moved to a spreadsheet feature tracker located at:
# C:\Users\theld\OneDrive - California Air Resources Board\OneDriveLinks\Data Management Plan\Operator Portal\operator_portal_feature_requests_002.xlsm


# todo - next steps
"""
* make updates from C:\Users\theld\OneDrive - California Air Resources Board\OneDriveLinks\Data Management Plan\Operator Portal\operator_portal_feature_requests_010.xlsm
  * Start with Portal UI/UX Requests
  * Change firstname/lastname to just name

items from my notebook on the 4/3/25 dry-run
  * remove notification timestamps from spreadsheet (done?)
  * notifications are sent to ISD from RD
  * Dan OK with changing drop downs from foreign key lookups for greater flexibility (could take some doing though) ...

# Continuing code refactor to clean up, organize, code before new functionality added.

# code refactor to move file handling out of app.py
# remove Operator Notification Timestamp from oil and gas and landfill
* 	Change 'not a citation' to 'not an enforcement action' - hmmm, i can't remember the context of this, so hunt around for these words

creating gpt_recommendations_02 because i may have put some bugs into gpt_recommendations_01.
I plan on abandoning 01


Forget me nots
----------------------------
* check new spreadsheets, create a readme file, post on review site, send email out
"""
