"""
Old Code.
"""
import decimal
import json
import logging
import datetime
# from datetime import datetime

logger = logging.getLogger(__name__)

def json_file_to_dict_old(file_name):
  """
  Read a .json file and return it as a dictionary if possible.
  If the json file contents is a list of dictionaries, only the first dictionary will be returned.

  Args:
    file_name (Path): path to .json file on server

  Returns (dict|None): dictionary contents of json file (if possible)

  Notes:
    This is outdated, use json_file_to_dict instead
  """
  dict_ = None
  logger.debug(f"Attempting to load file with json format named: {file_name}")
  file_as_json = file_to_json(file_name)
  # logger.debug(f"{file_as_json=}")

  if file_as_json:
    logger.debug(f"Json file with non-zero content successfully uploaded: {file_name}")
    logger.debug(f"{type(file_as_json)=}")

    if isinstance(file_as_json, list):
      msg = (f"Json content appears to be a list of {len(file_as_json)} items.  "
             f"Only the first item will be processed and the other entries will be ignored.")
      logger.warning(msg)
      logger.debug(f"{file_as_json[0]=}")
      file_as_json = file_as_json[0]

    if isinstance(file_as_json, dict):
      msg = f"Json content is a single dictionary (as expected)."
      logger.debug(msg)
      logger.debug(f"{file_as_json=}")
      dict_ = file_as_json
    else:
      msg = f"Json content must be a list of dictionaries or a single dictionary not {type(file_as_json)}."
      raise ValueError(msg)
  else:
    logger.debug(f"Json file did not appear to have content: {file_name}")

  logger.debug(f"The first dictionary in the json files content are: {dict_}")

  return dict_

