"""
This file contains the hard coded schemas that were created by hand
versions v01 and v02 by inspecting xl spreadsheets.

This file is still used to create the legacy v01 and v02 schema files, but
is not actively maintained or updated.
"""

import datetime

import arb.__get_logger as get_logger

logger, pp_log = get_logger.get_logger(__name__, __file__)

xl_schemas = {"oil_and_gas_v01": None,
              "oil_and_gas_v02": None,
              "oil_and_gas_v03": None,
              "landfill_v01": None,
              "landfill_v02": None,
              "landfill_v03": None,
              }

oil_and_gas_v01 = {
  # html includes id_feedback_form
  "facility_name": {"value_address": "$D$6",
                    "label_address": "$B$6",
                    "label": "Facility Name:",
                    "value_type": str},

  "id_arb_eggrt": {"value_address": "$D$7",
                   "label_address": "$B$7",
                   "label": "Facility's Cal e-GGRT ARB ID, if known:",
                   "value_type": str},

  # html form uses contact_first_name and contact_last_name as separate fields (rather than a space seperated field)
  "contact_name": {"value_address": "$D$8",
                   "label_address": "$B$8",
                   "label": "Contact Person Name:",
                   "value_type": str},  # first/last

  "contact_phone": {"value_address": "$D$9",
                    "label_address": "$B$9",
                    "label": "Phone Number:",
                    "value_type": str},

  "contact_email": {"value_address": "$D$10",
                    "label_address": "$B$10",
                    "label": "Email Address:",
                    "value_type": str},

  "id_incidence": {"value_address": "$D$11",
                   "label_address": "$B$11",
                   "label": "Emission ID (provided by CARB):",
                   "value_type": int},

  "notification_timestamp": {"value_address": "$D$12",
                             "label_address": "$B$12",
                             "label": "Date of notification from CARB (provided by CARB):",
                             "value_type": datetime.datetime},

  # html includes id_plume
  # since there may be multiple comma seperated values, convert as a str
  "lat_and_long": {"value_address": "$D$13",
                   "label_address": "$B$13",
                   "label": "Estimated lat/lon coordinates (provided by CARB):",
                   "value_type": str},

  # html form uses lat_arb and long_arb as separate fields (rather than a comma seperated field
  "observation_timestamp": {"value_address": "$D$14",
                            "label_address": "$B$14",
                            "label": "Date(s) of plume observation (provided by CARB):",
                            "value_type": datetime.datetime},

  "venting_exclusion": {"value_address": "$D$17",
                        "label_address": "$B$17",
                        "label": "Was the plume a result of activity-based venting that is being reported per section 95669.1(b)(1) of the Oil and Gas Methane Regulation?",
                        "value_type": str},

  "venting_description_1": {"value_address": "$B$19",
                            "label_address": "$B$18",
                            "label": 'Description of the venting (brief summary of the source of the venting and why the venting occurred): [if answered "yes" to question 10]',
                            "value_type": str},

  "inspection_timestamp": {"value_address": "$D$22",
                           "label_address": "$B$22",
                           "label": "Date of owner/operator's follow-up ground inspection:",
                           "value_type": datetime.datetime},

  "inspection_type": {"value_address": "$D$23",
                      "label_address": "$B$23",
                      "label": "Type of initial inspection performed:",
                      "value_type": str},

  "found_source_type": {"value_address": "$D$24",
                        "label_address": "$B$24",
                        "label": "Type of source found:",
                        "value_type": str},

  "initial_mitigation_plan": {"value_address": "$B$25",
                              "label_address": "$B$26",
                              "label": "Initial mitigation plan, unless a venting source or no source was found:",
                              "value_type": str},

  "venting_description_2": {"value_address": "$B$30",
                            "label_address": "$B$29",
                            "label": "Description of the venting (brief summary of the source of the venting and why the venting occurred):",
                            "value_type": str},

  "ogi_survey": {"value_address": "$D$33",
                 "label_address": "$B$33",
                 "label": "If an OGI survey indicated an unintentional emission source, which of the options to the right applies?",
                 "value_type": str},

  "equipment_at_source": {"value_address": "$D$34",
                          "label_address": "$B$34",
                          "label": "What type of equipment is at the source of the emissions?",
                          "value_type": str},

  "equipment_other_description": {"value_address": "$B$36",
                                  "label_address": "$B$35",
                                  "label": "If 'other' please describe:",
                                  "value_type": str},

  "component_at_source": {"value_address": "$D$37",
                          "label_address": "$B$37",
                          "label": "What type of component is at the source of the emissions (if the source is a component)?",
                          "value_type": str},

  "component_other_description": {"value_address": "$B$39",
                                  "label_address": "$B$38",
                                  "label": "If 'other' please describe:",
                                  "value_type": str},

  "initial_method_21_timestamp": {"value_address": "$D$41",
                                  "label_address": "$B$41",
                                  "label": "Date of initial Method 21 measurement, if applicable:",
                                  "value_type": datetime.datetime},

  "initial_leak_concentration": {"value_address": "$D$42",
                                 "label_address": "$B$42",
                                 "label": "Initial leak concentration, if applicable (ppmv):",
                                 "value_type": float},

  "repair_timestamp": {"value_address": "$D$43",
                       "label_address": "$B$43",
                       "label": "Repair date & time:",
                       "value_type": datetime.datetime},

  "final_repair_concentration": {"value_address": "$D$44",
                                 "label_address": "$B$44",
                                 "label": "Final repair concentration, if applicable (ppmv):",
                                 "value_type": float},

  "repair_description": {"value_address": "$B$48",
                         "label_address": "$B$47",
                         "label": "Mitigation actions taken:",
                         "value_type": str},

  # additional_notes is in the web-form but not the spreadsheet
}

xl_schemas["oil_and_gas_v01"] = oil_and_gas_v01

oil_and_gas_v02 = {
  "id_incidence": {"value_address": "$D$24",
                   "label_address": "$B$24",
                   "label": "1.  Incidence/Emission ID:",
                   "value_type": int},

  "id_plume": {"value_address": "$D$25",
               "label_address": "$B$25",
               "label": "2.  Plume ID(s):",
               "value_type": int},

  "observation_timestamp": {"value_address": "$D$26",
                            "label_address": "$B$26",
                            "label": "3.  Plume Observation Timestamp(s):",
                            "value_type": datetime.datetime},

  # todo - lat_and_long's are now on separate lines, this will likely mess up the naming scheme
  "lat_carb": {"value_address": "$D$27",
               "label_address": "$B$27",
               "label": "4.  Plume CARB Estimated Latitude:",
               "value_type": str},

  "long_carb": {"value_address": "$D$28",
                "label_address": "$B$28",
                "label": "5.  Plume CARB Estimated Longitude:",
                "value_type": str},

  "notification_timestamp": {"value_address": "$D$29",
                             "label_address": "$B$29",
                             "label": "6.  Operator Notification Timestamp:",
                             "value_type": datetime.datetime},

  "facility_name": {"value_address": "$D$33",
                    "label_address": "$B$33",
                    "label": "Q1.  Facility Name:",
                    "value_type": str},

  "id_arb_eggrt": {"value_address": "$D$34",
                   "label_address": "$B$34",
                   "label": "Q2.  Facility's Cal e-GGRT ARB ID (if known):",
                   "value_type": str},

  # html form uses contact_first_name and contact_last_name as separate fields (rather than a space seperated field)
  "contact_name": {"value_address": "$D$35",
                   "label_address": "$B$35",
                   "label": "Q3.  Contact Name:",
                   "value_type": str},  # first/last

  "contact_phone": {"value_address": "$D$36",
                    "label_address": "$B$36",
                    "label": "Q4.  Contact Phone Number:",
                    "value_type": str},

  "contact_email": {"value_address": "$D$37",
                    "label_address": "$B$37",
                    "label": "Q5.  Contact Email Address:",
                    "value_type": str},

  "venting_exclusion": {"value_address": "$D$41",
                        "label_address": "$B$41",
                        "label": "Q6.  Was the plume a result of activity-based venting that is being reported per section 95669.1(b)(1) of the Oil and Gas Methane Regulation?",
                        "value_type": str},

  "venting_description_1": {"value_address": "$D$42",
                            "label_address": "$B$42",
                            "label": "Q7.  If you answered 'Yes' to Q6, please provide a brief summary of the source of the venting defined by Regulation 95669.1(b)(1) and why the venting occurred.",
                            "value_type": str},

  "inspection_timestamp": {"value_address": "$D$46",
                           "label_address": "$B$46",
                           "label": "Q8.  Date & time of owner/operator's follow-up ground inspection:",
                           "value_type": datetime.datetime},

  "inspection_type": {"value_address": "$D$47",
                      "label_address": "$B$47",
                      "label": "Q9.  Type of initial inspection performed:",
                      "value_type": str},

  "found_source_type": {"value_address": "$D$48",
                        "label_address": "$B$48",
                        "label": "Q10.  Type of source found:",
                        "value_type": str},

  "venting_description_2": {"value_address": "$D$49",
                            "label_address": "$B$49",
                            "label": "Q11.  If you answered 'Venting' to Q10, please provide a brief summary of the source of the venting discovered during the ground inspection and why the venting occurred.",
                            "value_type": str},

  "initial_mitigation_plan": {"value_address": "$D$50",
                              "label_address": "$B$50",
                              "label": "Q12.  If you answered an 'Unintentional emission source (found with OGI)' or 'Leak (found with Method 21)' to Q10, please provide a description of your initial mitigation plan:",
                              "value_type": str},

  "ogi_survey": {"value_address": "$D$54",
                 "label_address": "$B$54",
                 "label": "Q13.  If an OGI survey indicated an unintentional emission source, which of the options to the right applies?",
                 "value_type": str},

  "equipment_at_source": {"value_address": "$D$55",
                          "label_address": "$B$55",
                          "label": "Q14.  What type of equipment is at the source of the emissions?",
                          "value_type": str},

  "equipment_other_description": {"value_address": "$D$56",
                                  "label_address": "$B$56",
                                  "label": "Q15.  If you answered 'Other' for Q14, please provide an additional description of the equipment.",
                                  "value_type": str},

  "component_at_source": {"value_address": "$D$57",
                          "label_address": "$B$57",
                          "label": "Q16.  If your source is a component, what type of component is at the source of the emissions?",
                          "value_type": str},

  "component_other_description": {"value_address": "$D$58",
                                  "label_address": "$B$58",
                                  "label": "Q17.  If you answered 'Other' for Q16, please provide an additional description of the component.",
                                  "value_type": str},

  "initial_method_21_timestamp": {"value_address": "$D$59",
                                  "label_address": "$B$59",
                                  "label": "Q18.  Date & time of initial Method 21 measurement (if applicable):",
                                  "value_type": datetime.datetime},

  "initial_leak_concentration": {"value_address": "$D$60",
                                 "label_address": "$B$60",
                                 "label": "Q19.  Initial leak concentration in ppmv (if applicable):",
                                 "value_type": float},

  "repair_timestamp": {"value_address": "$D$61",
                       "label_address": "$B$61",
                       "label": "Q20.  Repair/mitigation completion date & time (if applicable):",
                       "value_type": datetime.datetime},

  "final_repair_concentration": {"value_address": "$D$62",
                                 "label_address": "$B$62",
                                 "label": "Q21.  Final repair concentration in ppmv (if applicable):",
                                 "value_type": float},

  "repair_description": {"value_address": "$D$63",
                         "label_address": "$B$63",
                         "label": "Q22.  Repair/Mitigation actions taken (if applicable):",
                         "value_type": str},


  "additional_notes": {"value_address": "$D$67",
                       "label_address": "$B$67",
                       "label": "Q23. Additional notes or comments:",
                       "value_type": str},

}

xl_schemas["oil_and_gas_v02"] = oil_and_gas_v02

landfill_v01 = {
  "facility_name": {"value_address": "$C$4",
                    "label_address": "$B$4",
                    "label": "Facility Name:",
                    "value_type": str},

  # html form uses contact_first_name and contact_last_name as separate fields (rather than a space seperated field)
  "contact_name": {"value_address": "$C$5",
                   "label_address": "$B$5",
                   "label": "Contact Name:",
                   "value_type": str},  # first/last

  "contact_phone": {"value_address": "$C$6",
                    "label_address": "$B$6",
                    "label": "Phone Number:",
                    "value_type": str},

  "contact_email": {"value_address": "$C$7",
                    "label_address": "$B$7",
                    "label": "Email Address:",
                    "value_type": str},

  "id_incidence": {"value_address": "$C$10",
                   "label_address": "$B$10",
                   "label": "Incidence ID:",
                   "value_type": int},

  "id_plume": {"value_address": "$C$11",
               "label_address": "$B$11",
               "label": "Plume IDs:",
               "value_type": int},

  # html form uses lat_arb and long_arb as separate fields (rather than a comma seperated field)
  # since there may be multiple comma seperated values, convert as a str
  "lat_and_long": {"value_address": "$C$12",
                   "label_address": "$B$12",
                   "label": "Estimated lat/lon coordinates:",
                   "value_type": str},

  "observation_timestamp": {"value_address": "$C$13",
                            "label_address": "$B$13",
                            "label": "Date(s) of plume observed:",
                            "value_type": datetime.datetime},

  "inspection_timestamp": {"value_address": "$C$16",
                           "label_address": "$B$16",
                           "label": "Date of operator's follow-up ground survey:",
                           "value_type": datetime.datetime},

  "instrument": {"value_address": "$C$17",
                 "label_address": "$B$17",
                 "label": "Instrument used to locate the leak (e.g., Fisher Scientific TVA2020; RKI Multigas Analyzer Eagle 2; TDL):",
                 "value_type": str},

  "emission_identified_flag_fk": {"value_address": "$C$18",
                                  "label_address": "$B$18",
                                  "label": "Was an emission source identified by follow-up monitoring? If yes, answer 11 - 17, if no, skip 11 - 17.",
                                  "value_type": str},

  "initial_leak_concentration": {"value_address": "$C$19",
                                 "label_address": "$B$19",
                                 "label": "a. Concentration of methane leak (ppmv):",
                                 "value_type": float},

  "lat_and_long_revised": {"value_address": "$C$20",
                           "label_address": "$B$20",
                           "label": "b. Operator revised coordinates (lat,lon), if applicable:",
                           "value_type": float},

  "emission_type_fk": {"value_address": "$C$21",
                       "label_address": "$B$21",
                       "label": "Select from the drop-down menu which option best matches the description of the emissions?",
                       "value_type": str},

  "emission_type_notes": {"value_address": "$B$23",
                          "label_address": "$B$22",
                          "label": "Description:",
                          "value_type": str},

  "emission_location": {"value_address": "$C$24",
                        "label_address": "$B$24",
                        "label": "Select from the drop-down menu which option best describes the location of the emission source?",
                        "value_type": str},

  "emission_location_notes": {"value_address": "$B$26",
                              "label_address": "$B$25",
                              "label": "Please provide a more detailed description of the location, including grid number or component name, if applicable:",
                              "value_type": str},

  "emission_cause": {"value_address": "$C$27",
                     "label_address": "$B$27",
                     "label": "a. Select the most likely primary cause of the leak (Required):",
                     "value_type": str},

  "emission_cause_secondary": {"value_address": "$C$29",
                               "label_address": "$B$29",
                               "label": "b. Select the most likely secondary cause of the leak (Optional):",
                               "value_type": str},

  "emission_cause_tertiary": {"value_address": "$C$31",
                              "label_address": "$B$31",
                              "label": "c. Select the most likely tertiary cause of the leak (Optional):",
                              "value_type": str},

  "emission_cause_notes": {"value_address": "$B$33",
                           "label_address": "$B$32",
                           "label": "Please provide a more detailed description of the cause(s), including the reason for and duration of any construction activity or downtime:",
                           "value_type": str},

  # may want to call mitigation_actions (operator_comment)
  "mitigation_actions": {"value_address": "$B$36",
                         "label_address": "$B$35",
                         "label": "Mitigation actions taken:",
                         "value_type": str},

  "mitigation_timestamp": {"value_address": "$C$37",
                           "label_address": "$B$37",
                           "label": "Repair date:",
                           "value_type": datetime.datetime},

  "re_monitored_concentration": {"value_address": "$C$38",
                                 "label_address": "$B$38",
                                 "label": "Re-monitored methane concentration after repair (ppmv):",
                                 "value_type": float},

  # not sure if this is the concentration or date?
  "most_recent_prior_inspection": {"value_address": "$C$39",
                                   "label_address": "$B$39",
                                   "label": "Most recent leak monitoring prior to this notification:",
                                   "value_type": str},

  "last_surface_monitoring_timestamp": {"value_address": "$C$40",
                                        "label_address": "$B$40",
                                        "label": "a. Date of last surface emissions monitoring:",
                                        "value_type": datetime.datetime},

  "last_component_leak_monitoring_timestamp": {"value_address": "$C$41",
                                               "label_address": "$B$41",
                                               "label": "b. Date of last component leak monitoring:",
                                               "value_type": datetime.datetime},

  "included_in_last_lmr": {"value_address": "$C$42",
                           "label_address": "$B$42",
                           "label": "Was this location monitored in the previous quarterly/annual Landfill Methane Regulation (LMR) surface emissions or quarterly component leak monitoring?",
                           "value_type": str},

  "included_in_last_lmr_description": {"value_address": "$B$44",
                                       "label_address": "$B$43",
                                       "label": "If not, please state why the area was excluded from monitoring (construction, active working face, steep slope, etc.):",
                                       "value_type": str},

  "planned_for_next_lmr": {"value_address": "$C$45",
                           "label_address": "$B$45",
                           "label": "Is this location planned for inclusion in the next quarterly/annual LMR monitoring?",
                           "value_type": str},

  "planned_for_next_lmr_description": {"value_address": "$B$47",
                                       "label_address": "$B$46",
                                       "label": "Please state why the area will not be monitored (e.g., construction, active working face, steep slope, etc.):",
                                       "value_type": str},
}

xl_schemas["landfill_v01"] = landfill_v01

landfill_v02 = {
  "id_incidence": {"value_address": "$D$27",
                   "label_address": "$B$27",
                   "label": "1.  Incidence/Emission ID:",
                   "value_type": int},

  "id_plume": {"value_address": "$D$28",
               "label_address": "$B$28",
               "label": "2.  Plume ID(s):",
               "value_type": int},

  "observation_timestamp": {"value_address": "$D$29",
                            "label_address": "$B$29",
                            "label": "3.  Plume Observation Timestamp(s):",
                            "value_type": datetime.datetime},

  # todo - lat_and_long's are now on separate lines, this will likely mess up the naming scheme
  "lat_carb": {"value_address": "$D$30",
               "label_address": "$B$30",
               "label": "4.  Plume CARB Estimated Latitude:",
               "value_type": str},

  "long_carb": {"value_address": "$D$31",
                "label_address": "$B$31",
                "label": "5.  Plume CARB Estimated Longitude:",
                "value_type": str},

  "notification_timestamp": {"value_address": "$D$32",
                             "label_address": "$B$32",
                             "label": "6.  Operator Notification Timestamp:",
                             "value_type": datetime.datetime},

  "facility_name": {"value_address": "$D$36",
                    "label_address": "$B$36",
                    "label": "Q1.  Facility Name:",
                    "value_type": str},

  "id_arb_eggrt": {"value_address": "$D$37",
                   "label_address": "$B$37",
                   "label": "Q2.  Facility's Cal e-GGRT ARB ID (if known):",
                   "value_type": str},

  # html form uses contact_first_name and contact_last_name as separate fields (rather than a space seperated field)
  "contact_name": {"value_address": "$D$38",
                   "label_address": "$B$38",
                   "label": "Q3.  Contact Name:",
                   "value_type": str},  # first/last

  "contact_phone": {"value_address": "$D$39",
                    "label_address": "$B$39",
                    "label": "Q4.  Contact Phone Number:",
                    "value_type": str},

  "contact_email": {"value_address": "$D$40",
                    "label_address": "$B$40",
                    "label": "Q5.  Contact Email Address:",
                    "value_type": str},

  "inspection_timestamp": {"value_address": "$D$44",
                           "label_address": "$B$44",
                           "label": "Q6.  Date & time of owner/operator's follow-up ground inspection:",
                           "value_type": datetime.datetime},

  "instrument": {"value_address": "$D$45",
                 "label_address": "$B$45",
                 "label": "Q7.  Instrument used to locate the leak (e.g., Fisher Scientific TVA2020; RKI Multigas Analyzer Eagle 2; TDL):",
                 "value_type": str},

  "emission_identified_flag_fk": {"value_address": "$D$46",
                                  "label_address": "$B$46",
                                  "label": "Q8.  Was an emission source identified by follow-up monitoring?",
                                  "value_type": str},

  "initial_leak_concentration": {"value_address": "$D$50",
                                 "label_address": "$B$50",
                                 "label": "Q9:  Concentration of methane leak associated with Q8 (in ppmv):",
                                 "value_type": float},

  "lat_revised": {"value_address": "$D$51",
                  "label_address": "$B$51",
                  "label": "Q10.  Operator revised latitude associated with leak (if applicable):",
                  "value_type": float},

  "long_revised": {"value_address": "$D$52",
                   "label_address": "$B$52",
                   "label": "Q11.  Operator revised longitude associated with leak (if applicable):",
                   "value_type": float},

  "emission_type_fk": {"value_address": "$D$53",
                       "label_address": "$B$53",
                       "label": "Q12:  Select from the drop-down menu which option best matches the description of the emissions?",
                       "value_type": str},

  "emission_type_notes": {"value_address": "$D$54",
                          "label_address": "$B$54",
                          "label": "Q13.  Please provide additional details of the emission source associated with Q12:",
                          "value_type": str},

  "emission_location": {"value_address": "$D$55",
                        "label_address": "$B$55",
                        "label": "Q14.  Select from the drop-down menu which option best describes the location of the emission source?",
                        "value_type": str},

  "emission_location_notes": {"value_address": "$D$56",
                              "label_address": "$B$56",
                              "label": "Q15.  Please provide a more detailed description of the location, including grid number or component name, if applicable:",
                              "value_type": str},

  "emission_cause": {"value_address": "$D$57",
                     "label_address": "$B$57",
                     "label": "Q16.  Select the most likely primary cause of the leak:",
                     "value_type": str},

  "emission_cause_secondary": {"value_address": "$D$58",
                               "label_address": "$B$58",
                               "label": "Q17 (Optional).  Select the most likely secondary cause of the leak:",
                               "value_type": str},

  "emission_cause_tertiary": {"value_address": "$D$59",
                              "label_address": "$B$59",
                              "label": "Q18 (Optional).  Select the most likely tertiary cause of the leak:",
                              "value_type": str},

  "emission_cause_notes": {"value_address": "$D$60",
                           "label_address": "$B$60",
                           "label": "Q19.  Please provide a more detailed description of the cause(s), including the reason for and duration of any construction activity or downtime:",
                           "value_type": str},

  # may want to call mitigation_actions (operator_comment)
  "mitigation_actions": {"value_address": "$D$64",
                         "label_address": "$B$64",
                         "label": "Q20.  Mitigation actions taken:",
                         "value_type": str},

  "mitigation_timestamp": {"value_address": "$D$65",
                           "label_address": "$B$65",
                           "label": "Q21.  Repair date:",
                           "value_type": datetime.datetime},

  "re_monitored_concentration": {"value_address": "$D$66",
                                 "label_address": "$B$66",
                                 "label": "Q22.  Re-monitored methane concentration after repair (ppmv):",
                                 "value_type": float},

  # not sure if this is the concentration or date?
  "most_recent_prior_inspection": {"value_address": "$D$67",
                                   "label_address": "$B$67",
                                   "label": "Q23.  Most recent leak monitoring prior to this notification:",
                                   "value_type": str},

  "last_surface_monitoring_timestamp": {"value_address": "$D$68",
                                        "label_address": "$B$68",
                                        "label": "Q24.  Date of last surface emissions monitoring:",
                                        "value_type": datetime.datetime},

  "last_component_leak_monitoring_timestamp": {"value_address": "$D$69",
                                               "label_address": "$B$69",
                                               "label": "Q25.  Date of last component leak monitoring:",
                                               "value_type": datetime.datetime},

  "included_in_last_lmr": {"value_address": "$D$70",
                           "label_address": "$B$70",
                           "label": "Q26.  Was this location monitored in the previous quarterly/annual Landfill Methane Regulation (LMR) surface emissions or quarterly component leak monitoring?",
                           "value_type": str},

  "included_in_last_lmr_description": {"value_address": "$D$71",
                                       "label_address": "$B$71",
                                       "label": "Q27.  If 'No' to Q26, please state why the area was excluded from monitoring (construction, active working face, steep slope, etc.)",
                                       "value_type": str},

  "planned_for_next_lmr": {"value_address": "$D$72",
                           "label_address": "$B$72",
                           "label": "Q28.  Is this location planned for inclusion in the next quarterly/annual LMR monitoring?",
                           "value_type": str},

  "planned_for_next_lmr_description": {"value_address": "$D$73",
                                       "label_address": "$B$73",
                                       "label": "Q29.  If 'No' to Q28, please state why the area will not be monitored (e.g., construction, active working face, steep slope, etc.):",
                                       "value_type": str},

  # todo - additional_notes is a new addition, make sure it works
  "additional_notes": {"value_address": "$D$77",
                       "label_address": "$B$77",
                       "label": "Q30. Additional notes or comments:",
                       "value_type": str},
}

xl_schemas["landfill_v02"] = landfill_v02

landfill_v03 = {
  "additional_notes": {
    "label": "Q30. Additional notes or comments:",
    "label_address": "$B$77",
    "value_address": "$D$77",
  },
  "contact_email": {
    "label": "Q5.  Contact Email Address:",
    "label_address": "$B$40",
    "value_address": "$D$40",
  },
  "contact_name": {
    "label": "Q3.  Contact Name:",
    "label_address": "$B$38",
    "value_address": "$D$38",
  },
  "contact_phone": {
    "label": "Q4.  Contact Phone Number:",
    "label_address": "$B$39",
    "value_address": "$D$39",
  },
  "emission_cause": {
    "label": "Q16.  Select the most likely primary cause of the leak:",
    "label_address": "$B$57",
    "value_address": "$D$57",
  },
  "emission_cause_notes": {
    "label": "Q19.  Please provide a more detailed description of the cause(s), including the reason for and duration of any construction activity or downtime:",
    "label_address": "$B$60",
    "value_address": "$D$60",
  },
  "emission_cause_secondary": {
    "label": "Q17 (Optional).  Select the most likely secondary cause of the leak:",
    "label_address": "$B$58",
    "value_address": "$D$58",
  },
  "emission_cause_tertiary": {
    "label": "Q18 (Optional).  Select the most likely tertiary cause of the leak:",
    "label_address": "$B$59",
    "value_address": "$D$59",
  },
  "emission_identified_flag_fk": {
    "label": "Q8.  Was an emission source identified by follow-up monitoring?",
    "label_address": "$B$46",
    "value_address": "$D$46",
  },
  "emission_location": {
    "label": "Q14.  Select from the drop-down menu which option best describes the location of the emission source?",
    "label_address": "$B$55",
    "value_address": "$D$55",
  },
  "emission_location_notes": {
    "label": "Q15.  Please provide a more detailed description of the location, including grid number or component name, if applicable:",
    "label_address": "$B$56",
    "value_address": "$D$56",
  },
  "emission_type_fk": {
    "label": "Q12:  Select from the drop-down menu which option best matches the description of the emissions?",
    "label_address": "$B$53",
    "value_address": "$D$53",
  },
  "emission_type_notes": {
    "label": "Q13.  Please provide additional details of the emission source associated with Q12:",
    "label_address": "$B$54",
    "value_address": "$D$54",
  },
  "facility_name": {
    "label": "Q1.  Facility Name:",
    "label_address": "$B$36",
    "value_address": "$D$36",
  },
  "id_arb_eggrt": {
    "label": "Q2.  Facility's Cal e-GGRT ARB ID (if known): [#todo, may want a different id here]",
    "label_address": "$B$37",
    "value_address": "$D$37",
  },
  "id_incidence": {
    "label": "1.  Incidence/Emission ID:",
    "label_address": "$B$27",
    "value_address": "$D$27",
  },
  "id_plume": {
    "label": "2.  Plume ID(s):",
    "label_address": "$B$28",
    "value_address": "$D$28",
  },
  "included_in_last_lmr": {
    "label": "Q26.  Was this location monitored in the previous quarterly/annual Landfill Methane Regulation (LMR) surface emissions or quarterly component leak monitoring?",
    "label_address": "$B$70",
    "value_address": "$D$70",
  },
  "included_in_last_lmr_description": {
    "label": "Q27.  If 'No' to Q26, please state why the area was excluded from monitoring (construction, active working face, steep slope, etc.)",
    "label_address": "$B$71",
    "value_address": "$D$71",
  },
  "initial_leak_concentration": {
    "label": "Q9:  Concentration of methane leak associated with Q8 (in ppmv):",
    "label_address": "$B$50",
    "value_address": "$D$50",
  },
  "inspection_timestamp": {
    "label": "Q6.  Date & time of owner/operator's follow-up ground inspection:",
    "label_address": "$B$44",
    "value_address": "$D$44",
  },
  "instrument": {
    "label": "Q7.  Instrument used to locate the leak (e.g., Fisher Scientific TVA2020; RKI Multigas Analyzer Eagle 2; TDL):",
    "label_address": "$B$45",
    "value_address": "$D$45",
  },
  "last_component_leak_monitoring_timestamp": {
    "label": "Q25.  Date of last component leak monitoring:",
    "label_address": "$B$69",
    "value_address": "$D$69",
  },
  "last_surface_monitoring_timestamp": {
    "label": "Q24.  Date of last surface emissions monitoring:",
    "label_address": "$B$68",
    "value_address": "$D$68",
  },
  "lat_carb": {
    "label": "4.  Plume CARB Estimated Latitude:",
    "label_address": "$B$30",
    "value_address": "$D$30",
  },
  "lat_revised": {
    "label": "Q10.  Operator revised latitude associated with leak (if applicable):",
    "label_address": "$B$51",
    "value_address": "$D$51",
  },
  "long_carb": {
    "label": "5.  Plume CARB Estimated Longitude:",
    "label_address": "$B$31",
    "value_address": "$D$31",
  },
  "long_revised": {
    "label": "Q11.  Operator revised longitude associated with leak (if applicable):",
    "label_address": "$B$52",
    "value_address": "$D$52",
  },
  "mitigation_actions": {
    "label": "Q20.  Mitigation actions taken:",
    "label_address": "$B$64",
    "value_address": "$D$64",
  },
  "mitigation_timestamp": {
    "label": "Q21.  Repair date:",
    "label_address": "$B$65",
    "value_address": "$D$65",
  },
  "most_recent_prior_inspection": {
    "label": "Q23.  Most recent leak monitoring prior to this notification:",
    "label_address": "$B$67",
    "value_address": "$D$67",
  },
  "notification_timestamp": {
    "label": "6.  Operator Notification Timestamp:",
    "label_address": "$B$32",
    "value_address": "$D$32",
  },
  "observation_timestamp": {
    "label": "3.  Plume Observation Timestamp(s):",
    "label_address": "$B$29",
    "value_address": "$D$29",
  },
  "planned_for_next_lmr": {
    "label": "Q28.  Is this location planned for inclusion in the next quarterly/annual LMR monitoring?",
    "label_address": "$B$72",
    "value_address": "$D$72",
  },
  "planned_for_next_lmr_description": {
    "label": "Q29.  If 'No' to Q28, please state why the area will not be monitored (e.g., construction, active working face, steep slope, etc.):",
    "label_address": "$B$73",
    "value_address": "$D$73",
  },
  "re_monitored_concentration": {
    "label": "Q22.  Re-monitored methane concentration after repair (ppmv):",
    "label_address": "$B$66",
    "value_address": "$D$66",
  },
}

xl_schemas["landfill_v03"] = landfill_v03

default_value_types_v01 = {
  "additional_notes": str,
  "component_at_source": str,
  "component_other_description": str,
  "contact_email": str,
  "contact_name": str,
  "contact_phone": str,
  "emission_cause": str,
  "emission_cause_notes": str,
  "emission_cause_secondary": str,
  "emission_cause_tertiary": str,
  "emission_identified_flag_fk": str,
  "emission_location": str,
  "emission_location_notes": str,
  "emission_type_fk": str,
  "emission_type_notes": str,
  "equipment_at_source": str,
  "equipment_other_description": str,
  "facility_name": str,
  "final_repair_concentration": float,
  "found_source_type": str,
  "id_arb_eggrt": str,
  "id_incidence": int,
  "id_message": str,
  "id_plume": int,
  "included_in_last_lmr": str,
  "included_in_last_lmr_description": str,
  "initial_leak_concentration": float,
  "initial_method_21_timestamp": datetime.datetime,
  "initial_mitigation_plan": str,
  "inspection_timestamp": datetime.datetime,
  "inspection_type": str,
  "instrument": str,
  "last_component_leak_monitoring_timestamp": datetime.datetime,
  "last_surface_monitoring_timestamp": datetime.datetime,
  "lat_and_long": str,
  "lat_and_long_revised": float,
  "lat_carb": str,
  "lat_revised": float,
  "long_carb": str,
  "long_revised": float,
  "mitigation_actions": str,
  "mitigation_timestamp": datetime.datetime,
  "most_recent_prior_inspection": str,
  "notification_timestamp": datetime.datetime,
  "observation_timestamp": datetime.datetime,
  "ogi_survey": str,
  "planned_for_next_lmr": str,
  "planned_for_next_lmr_description": str,
  "re_monitored_concentration": float,
  "repair_description": str,
  "repair_timestamp": datetime.datetime,
  "venting_description_1": str,
  "venting_description_2": str,
  "venting_exclusion": str,
}

# oil and gas example payload
oil_and_gas_payload_01 = {

  "id_incidence": "4321",
  "id_plume": "1234",
  "observation_timestamp": "06/25/2024 00:00",
  "lat_carb": "35.3211",
  "long_carb": "-119.5808",
  "notification_timestamp": "06/27/2024 00:00",
  "id_message": "123-001",
  "facility_name": "Example Facility Name",
  "id_arb_eggrt": "Example Cal e-GGRT ARB ID",
  "contact_name": "Example Contact Person Name",
  "contact_phone": "555-555-5555",
  "contact_email": "me@email.com",
}

oil_and_gas_payload_02 = {

  "id_incidence": "1000011",
  "id_plume": "1234",
  "observation_timestamp": "06/25/2024 00:00",
  "lat_carb": "35.3211",
  "long_carb": "-119.5808",
  "notification_timestamp": "06/27/2024 00:00",

  "facility_name": "Facility Name",
  "id_arb_eggrt": "Cal e-GGRT ARB ID",
  "contact_name": "Contact Person Name",
  "contact_phone": "555-555-5555",
  "contact_email": "me@email.com",

  "venting_exclusion": "Please Select",
  "venting_description_1": "Q7 Answer.",

  "inspection_timestamp": "08/14/2023 00:00",
  "inspection_type": "Please Select",
  "found_source_type": "Please Select",
  "venting_description_2": "Q11 Answer.",
  "initial_mitigation_plan": "Q12 Answer.",

  "ogi_survey": "Please Select",
  "equipment_at_source": "Please Select",
  "equipment_other_description": "Q15 Answer.",
  "component_at_source": "Please Select",
  "component_other_description": "Q17 Answer.",
  "initial_method_21_timestamp": "08/13/2023 14:00",
  "initial_leak_concentration": "100",
  "repair_timestamp": "08/21/2023 16:00",
  "final_repair_concentration": "40",
  "repair_description": "Q22 Answer.",

  "additional_notes": "Q23 Answer.",
}

# landfill example
landfill_payload_01 = {
  "id_incidence": "153",
  "id_plume": "447",
  "observation_timestamp": "06/25/2024 00:00",
  "lat_carb": "35.3211",
  "long_carb": "-119.5808",
  "notification_timestamp": "06/27/2024 00:00",
  "id_message": "200-002",

  "facility_name": "Example Facility Name",
  "id_arb_swis": "Example Cal SWIS ID",
  "contact_name": "Example Contact Person Name",
  "contact_phone": "555-555-5555",
  "contact_email": "me@email.com",
}

landfill_payload_02 = {
  "id_incidence": "153",
  "id_plume": "447",
  "observation_timestamp": "06/25/2024 00:00",
  "lat_carb": "35.3211",
  "long_carb": "-119.5808",
  "notification_timestamp": "06/27/2024 00:00",

  "facility_name": "Facility Name",
  "id_arb_swis": "Cal e-GGRT ARB ID",
  "contact_name": "Contact Person Name",
  "contact_phone": "555-555-5555",
  "contact_email": "me@email.com",

  "inspection_timestamp": "08/14/2023 00:00",
  "instrument": "Q7 Answer.",
  "emission_identified_flag_fk": "Please Select",

  "initial_leak_concentration": "500",
  "lat_revised": "35.3211",
  "long_revised": "-119.5808",
  "emission_type_notes": "Q14 Answer.",
  "emission_location": "Gas Control Device/Control System Component",
  "emission_location_notes": "Q16 Answer.",
  "emission_cause": "Construction - Other",
  "emission_cause_secondary": "Offline Gas Collection Well(s)",
  "emission_cause_tertiary": "Construction - New Well Installation",
  "emission_cause_notes": "Q20 Answer.",

  "mitigation_actions": "Q21 Answer",
  "mitigation_timestamp": "12/15/2023 00:00",
  "re_monitored_concentration": "85",
  "most_recent_prior_inspection": "Not sure if this is a timestamp or a float?",
  "last_surface_monitoring_timestamp": "12/16/2023 00:00",
  "last_component_leak_monitoring_timestamp": "12/17/2023 00:00",
  "included_in_last_lmr": "No",
  "included_in_last_lmr_description": "Q26 Answer",
  "planned_for_next_lmr": "No",
  "planned_for_next_lmr_description": "Q28 Answer",

  "additional_notes": "Q31 Answer.",
}
if __name__ == "__main__":
  pass
