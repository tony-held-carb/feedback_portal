"""
Package to group spreadsheet related routines.
"""
from arb.__get_logger import get_logger

__version__ = "1.0.0"

logger, pp_log = get_logger()
