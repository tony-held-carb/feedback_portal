"""
Package to RSDAS general purpose utility routines.
"""
from arb.__get_logger import get_logger

__version__ = "1.0.0"
logger, pp_log = get_logger()
