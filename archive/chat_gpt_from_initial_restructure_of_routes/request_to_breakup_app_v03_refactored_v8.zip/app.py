"""
Flask app factory and setup logic.

Refactored from original monolithic app.py into a factory pattern
to allow for better testability, scalability, and deployment compatibility.

This file:
  - Initializes the Flask app
  - Loads configuration
  - Reflects the Postgres database schema
  - Registers blueprints and initializes extensions

To run the app:
  Use wsgi.py or an external WSGI server like Gunicorn.

All prior comments and TODOs retained or moved where appropriate.
"""

from flask import Flask
from jinja2 import StrictUndefined

from config import Config, db_initialize_and_create, reflect_database
from extensions import db
from globals import Globals
from constants import CA_TIME_ZONE, UTC_TIME_ZONE
from routes import main as main_blueprint


def create_app() -> Flask:
  """
  Application factory function.

  Returns:
    Flask: A configured Flask application instance.
  """
  app = Flask(__name__)

  # Load configuration into the app
  Config.configure_flask_app(app)

  # Jinja2 should raise errors for undefined variables
  app.jinja_env.undefined = StrictUndefined

  # Bind SQLAlchemy to the app
  db.init_app(app)

  with app.app_context():
    # Create database structure if needed
    db_initialize_and_create(app, db)

    # Reflect the current Postgres schema into SQLAlchemy
    base = reflect_database(app, db)
    app.base = base  # Store for use in routes via current_app.base

    # Load globals
    Globals.load_type_mapping(app, db, base)
    Globals.load_drop_downs(app, db)

  # Register application blueprints
  app.register_blueprint(main_blueprint)

  return app
