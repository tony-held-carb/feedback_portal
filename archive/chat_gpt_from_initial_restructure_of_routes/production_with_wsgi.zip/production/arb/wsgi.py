"""
WSGI entry point for Flask application.

To run from command line:
    cd production/arb
    python wsgi.py

To run with Flask CLI:
    flask run --app wsgi --debug

Ensure FLASK_ENV=development and FLASK_DEBUG=1 are set for full error tracebacks.
"""

import logging
from portal import create_app  # Assumes portal/__init__.py or app.py defines create_app

# Optional: direct logs to a file
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s",
    handlers=[
        logging.FileHandler("portal/logs/app.log", mode="a"),
        logging.StreamHandler()
    ]
)

app = create_app()

if __name__ == "__main__":
    app.run(debug=True)
